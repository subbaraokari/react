import React, { Component } from 'react';
import Blog from '../blog/Blog';
class App extends Component {
  render() {
    return (
      <div>
        <Blog />
      </div>
    )
  }
}
export default App;